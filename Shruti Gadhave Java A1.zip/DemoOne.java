package com.cdac.main;

import java.util.Scanner;
public class DemoOne {
	public static void areaofrectangle(int l, int b) {
		int a=l*b;
		System.out.println("area of rectangle\n"+a);
	}
	public static void areaoftriangle(int h, int b) {
		int a=(b*h)/2;
		System.out.println("area of triangle\n"+a);
	}
	

	public static void main(String args[]) {
		Scanner sc=new Scanner (System.in);
		System.out.println("enter 1 for rectangle and 2 for triangle");
		int choice=sc.nextInt();
		
		switch (choice)
		
		{
		case 1:
		System.out.println("enter length and width\n ");
		int l = sc.nextInt();
		int b = sc.nextInt();
		DemoOne.areaofrectangle(l,b);
		break;
		
		case 2:
		System.out.println("enter base and height\n ");
		int h = sc.nextInt();
		int b1 = sc.nextInt();
		DemoOne.areaoftriangle(h,b1);
		break;
		default:System.out.println("nothing");
		}
		
		
		
		
		
		
		
		
		
		
		/*try (Scanner sc = new Scanner(System.in)) 
		{
			int num=1;
			//System.out.println("choose the shape rectangle or triangle\n");
			sc.nextInt();
			System.out.println("choose the shape rectangle or triangle\n"+num);
			
		//switch expression
		switch(num) {
		
		case 1:
		int width=5;
		int height=10;
		int area=width*height;
		
		System.out.println("Area of rectangle="+area);
		break;
		
		case 2:
		float b=4,h =13,area1 ;  
        area1 = ( b*h) / 2 ;  
        
        System.out.println("Area of Triangle is: "+area1); 
		break;
		default:System.out.println("nothing");
		}
		}*/
	
		
		
	
		 
	
	
		}
	}
	

