package com.cdac.main;

public class DemoSeven {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=8;
		float f=88.9f;
		int b=(int)f;
		float e=a;
		System.out.println(b);
		System.out.println(e);



	}

}
