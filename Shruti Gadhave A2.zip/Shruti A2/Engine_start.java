

import java.util.*;

public class Engine_start {
	public static void start_engine(){
		System.out.println("Engine started");
	}
	public static void main(String[] args) {
		start_engine();
	}
}
